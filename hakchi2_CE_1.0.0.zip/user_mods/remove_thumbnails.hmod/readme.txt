=== No-thumbnails Hack ===

This module removes thumbnails at the bottom of the screen.
