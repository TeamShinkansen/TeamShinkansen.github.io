=== Password Protection Hack ===

This module adds password protection to NES/SNES Mini. Default password is Konami Code :)
