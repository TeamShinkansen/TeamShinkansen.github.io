=== Extra Space Hack ===

This is VERY EXPERIMENTAL mod for SNES Mini which moves your save-states data to unused partition of NAND flash.

This partition is only 50MB in size but it will free some space for games.

Please backup your save-states before using. I am not responsible for them.