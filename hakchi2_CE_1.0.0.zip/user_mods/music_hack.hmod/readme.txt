=== Music Hack ===

This module allows to disable NES/SNES Mini's menu music or replace it with your own music.

Just replace "music.wav" file if you want to hear your own music in the menu of NES Mini. It must be in PCM format.
